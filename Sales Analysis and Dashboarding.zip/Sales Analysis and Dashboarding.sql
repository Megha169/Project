CREATE DATABASE Retail_sales;
USE Retail_sales;

-- 1. Number of distinct transactions.
select count(distinct Transaction_ID) as No_of_transactions from retail_sales;

-- 2. Total revenue.
select sum(Total_Sale) from retail_sales as Total_Revenue;

-- 3. Top 10 customers by revenue.
select distinct Customer_ID,  sum(Total_Sale) as Total_Revenue_per_Customer from retail_sales 
group by Customer_ID order by Total_Revenue_per_Customer desc limit 10;

-- 4. Average, highest and lowest transaction amount.
Select avg(Total_Sale) as Avg_sale_amount, min(Total_Sale) as Min_Sale_amount, max(Total_Sale) as Max_Sale_amount from retail_sales;

-- 5. Sales above the overall average transaction amount.
Select count(*) as Sales_above_average from retail_sales where Total_Sale > (select avg(Total_Sale) from retail_sales);

-- 6. Number of transactions by gender.
select Gender, count(Transaction_ID) as No_of_transactions from retail_sales group by Gender order by No_of_transactions desc;

-- 7. Total sales by gender.
select Gender, sum(Total_Sale) as Total_Sale_by_Gender from retail_sales group by Gender order by Total_Sale_by_Gender desc;

-- 8. Monthly revenue in chronological order.
select Sale_Year, Sale_Month, Sale_Month_Name, sum(Total_Sale) as Monthy_Sale from retail_sales 
group by Sale_Year, Sale_Month, Sale_Month_Name order by Sale_Year, Sale_Month;

-- 9. Month-over-month revenue change with percentage.
With Monthy_Revenue as 
(Select Sale_Year, Sale_Month_Name, sum(Total_Sale) as Monthy_Revenue from retail_sales 
group by Sale_Year, Sale_Month_Name),
Previous_Month as 
(Select Sale_Year, Sale_Month_Name, Monthy_Revenue, lag(Monthy_Revenue) over(order by Sale_Year, Sale_Month_Name) as Previous_Month_Revenue from Monthy_Revenue)
Select Sale_Year, Sale_Month_Name, Monthy_Revenue, Previous_Month_Revenue, Monthy_Revenue - Previous_Month_Revenue as Revenue_Change,
Round(((Monthy_Revenue - Previous_Month_Revenue)/Previous_Month_Revenue) * 100, 2) as MoM_Revenue_Change_Percentage
from Previous_Month order by Sale_Year, Sale_Month_Name;

-- 10. Comparing average transaction value by product category.
SELECT Category, AVG(Total_Sale) AS Average_Transaction_Value FROM retail_sales
GROUP BY Category ORDER BY Average_Transaction_Value DESC;

-- 11. Revenue and units sold by product category.
select Category, 
sum(Quantiy) as Category_Units, 
sum(Total_Sale) as Category_Revenue from retail_sales group by Category order by Category_Revenue desc;

-- 12. Revenue contribution percentage for each category.
SELECT Category, SUM(Total_Sale) AS Category_Revenue, 
ROUND((SUM(Total_Sale) / (SELECT SUM(Total_Sale) FROM retail_sales) * 100), 2) AS Revenue_Contribution_Percentage
FROM retail_sales GROUP BY Category ORDER BY Revenue_Contribution_Percentage DESC;

-- 13. Rank within categories by revenue.
SELECT *, RANK() OVER (PARTITION BY Category ORDER BY Total_Sale DESC) as Transaction_Rank FROM retail_sales;

-- 14. Highest sale under each category by revenue.
WITH CTE_Rank as (SELECT *, RANK() OVER (PARTITION BY Category ORDER BY Total_Sale DESC) AS Transaction_Rank FROM retail_sales)
SELECT * FROM CTE_Rank WHERE Transaction_Rank = 1;

-- 15. Number of highest sale happened within each category by revenue.
With CTE_Rank as (SELECT *, RANK() OVER (PARTITION BY Category ORDER BY Total_Sale DESC) as Transaction_Rank FROM retail_sales)
Select Category, Transaction_Rank, Total_Sale, count(Transaction_Rank) as Total_Transaction from CTE_Rank 
where Transaction_Rank = 1 group by Category, Transaction_Rank, Total_Sale;

